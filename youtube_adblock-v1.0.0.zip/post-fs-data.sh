#!/system/bin/sh
# Post-fs-data script for YouTube AdBlock module

# Wait for system to be ready
sleep 5

# Run ad blocking script
/system/bin/youtube_adblock

# Set system properties
setprop youtube.adblock.enabled 1
setprop youtube.music.adblock.enabled 1
setprop net.adblock.enabled 1

exit 0
