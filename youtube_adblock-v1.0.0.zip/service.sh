#!/system/bin/sh
# Service script for YouTube AdBlock module

# Wait for system to be ready
sleep 15

# Run ad blocking script
/system/bin/youtube_adblock

# Set system properties
setprop youtube.adblock.enabled 1
setprop youtube.music.adblock.enabled 1
setprop net.adblock.enabled 1

# Flush DNS cache
ndc resolver flushdefaultif 2>/dev/null || true
ndc resolver clearnetdns 2>/dev/null || true

# Kill YouTube and YouTube Music to apply changes
am force-stop com.google.android.youtube 2>/dev/null || true
am force-stop com.google.android.apps.youtube.music 2>/dev/null || true

exit 0
