#!/system/bin/sh
# Uninstall script for YouTube AdBlock module

# Restore original hosts file if backup exists
if [ -f "/system/etc/hosts.backup" ]; then
    cp /system/etc/hosts.backup /system/etc/hosts
    rm /system/etc/hosts.backup
fi

# Remove ad blocking properties
setprop youtube.adblock.enabled 0
setprop youtube.music.adblock.enabled 0
setprop net.adblock.enabled 0

# Flush DNS cache
ndc resolver flushdefaultif 2>/dev/null || true
ndc resolver clearnetdns 2>/dev/null || true

# Kill YouTube and YouTube Music
am force-stop com.google.android.youtube 2>/dev/null || true
am force-stop com.google.android.apps.youtube.music 2>/dev/null || true

exit 0
